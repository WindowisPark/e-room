# app/api/v1/endpoints/attendance.py

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from datetime import date

from app import crud, schemas
from app.api import deps
from app.core.redis_helper import is_attendance_checked, mark_attendance

router = APIRouter()

@router.post("/attendance", response_model=schemas.AttendanceResponse)
def check_attendance(
    db: Session = Depends(deps.get_db),
    current_user: schemas.User = Depends(deps.get_current_user)
):
    """
    출석 체크 API
    - 사용자가 출석 버튼을 누를 때 호출됨
    - 하루에 한 번만 출석 가능 (Redis를 통해 중복 방지)
    - 출석 성공 시 DB에 기록하고, Redis에 오늘 출석 여부 저장
    - 응답에는 연속 출석일수 및 상태 메시지 포함
    """
    user_id = current_user.id

    if is_attendance_checked(user_id):
        return schemas.AttendanceResponse(
            success=False,
            message="이미 출석했습니다.",
            current_streak=crud.crud_attendance.get_current_streak(db, user_id),
            today_checked=True,
            today=date.today()
        )

    crud.crud_attendance.upsert_attendance(db, user_id)
    mark_attendance(user_id)

    return schemas.AttendanceResponse(
        success=True,
        message="출석이 완료되었습니다.",
        current_streak=crud.crud_attendance.get_current_streak(db, user_id),
        today_checked=True,
        today=date.today()
    )
