# app/crud/__init__.py
from app.crud.crud_user import user

# 다른 CRUD 모듈을 추가할 때마다 여기에 import 