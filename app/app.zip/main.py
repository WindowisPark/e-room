# ai-agent/app/main.py

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.v1 import auth
from app.core.config import settings
from app.api.v1.pdf_manager import router as pdf_router
from app.api.v1.admin import router as admin_router
from app.api.v1.endpoints import files  # 새로 추가
from app.services.file_service import ChunkManager 
import asyncio
from asyncio import create_task

# FastAPI 앱 초기화
app = FastAPI(
    title=settings.PROJECT_NAME,
    description="AI-Agent API with Authentication and PDF Management",
    version="1.0.0",
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
    docs_url=f"{settings.API_V1_STR}/docs",
    redoc_url=None
)

# 청크 Cleanup 태스크 설정
@app.on_event("startup")
async def startup_event():
    """청크 파일 정리를 위한 백그라운드 태스크 시작"""
    chunk_manager = ChunkManager()
    
    async def cleanup_loop():
        while True:
            try:
                await chunk_manager.cleanup_expired_chunks()
            except Exception as e:
                print(f"Chunk cleanup error: {str(e)}")  # 로깅 고려
            await asyncio.sleep(3600)  # 1시간마다 실행
    
    create_task(cleanup_loop())

# CORS 미들웨어 설정
if settings.BACKEND_CORS_ORIGINS:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[str(origin) for origin in settings.BACKEND_CORS_ORIGINS],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

# API 라우터 포함
app.include_router(
    auth.router,
    prefix=f"{settings.API_V1_STR}/auth",
    tags=["Authentication"]
)

# PDF 관리 API 추가
app.include_router(
    pdf_router,
    prefix=f"{settings.API_V1_STR}/pdf",
    tags=["PDF Manager"]
)

# Admin API 라우터
app.include_router(
    admin_router,
    prefix=f"{settings.API_V1_STR}/admin",
    tags=["Admin"]
)

# 파일 관리 API 추가
app.include_router(
    files.router,
    prefix=f"{settings.API_V1_STR}/users",
    tags=["Files"]
)

# 헬스 체크 엔드포인트
@app.get("/health", tags=["Health Check"])
async def health_check():
    """
    Redis와 DB 연결 상태를 포함한 상세 헬스 체크
    """
    from app.core.redis_helper import redis_client
    from app.db.session import SessionLocal
    
    status = {
        "service": "healthy",
        "redis": "unhealthy",
        "database": "unhealthy"
    }
    
    # Redis 연결 체크
    try:
        if redis_client and redis_client.ping():
            status["redis"] = "healthy"
    except:
        pass
        
    # DB 연결 체크
    try:
        db = SessionLocal()
        db.execute("SELECT 1")
        status["database"] = "healthy"
        db.close()
    except:
        pass
        
    return status

# Root 엔드포인트
@app.get("/", tags=["Root"])
def root():
    return {
        "message": "Welcome to AI-Agent API",
        "docs_url": f"{settings.API_V1_STR}/docs",
        "openapi_url": f"{settings.API_V1_STR}/openapi.json"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
