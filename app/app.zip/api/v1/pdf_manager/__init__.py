# app/api/v1/pdf_manager/__init__.py

from .pdf_routes import router

__all__ = ["router"]
