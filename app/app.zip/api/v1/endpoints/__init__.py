# app/api/v1/endpoints/__init__.py
from . import attendance
from . import payments
from . import question
from . import teams
from . import tags
from . import notifications