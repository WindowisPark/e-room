# app/services/file_service.py
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Body
from typing import List, Optional
from sqlalchemy.orm import Session
from pydantic import BaseModel
from app.core.config import settings
from app.core.security import get_current_user
from app.services.file_service import FileStorageManager, ChunkManager 
from app.schemas.user import User
from app.db.session import get_db
from app.core.redis_helper import get_cache, set_cache, build_cache_key, delete_cache

router = APIRouter()
file_manager = FileStorageManager()
chunk_manager = ChunkManager() 

class CompleteUploadRequest(BaseModel):
    file_id: str

@router.get("/{user_id}/folders")
async def list_user_folders(
    user_id: int,
    current_user: User = Depends(get_current_user),
    include_subfolders: bool = False,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """
    사용자의 폴더 목록을 조회합니다.
    """
    if current_user.id != user_id:
        raise HTTPException(status_code=403, detail="자신의 폴더만 조회할 수 있습니다")

    try:
        # Redis 캐시 키 생성
        cache_key = build_cache_key("folders", user_id, include_subfolders)
        
        # 캐시된 데이터 확인
        cached_folders = get_cache(cache_key)
        if cached_folders is not None:
            return {
                "status": "success",
                "data": cached_folders[skip:skip + limit],
                "cache_hit": True
            }

        # DB에서 폴더 목록 조회
        folders = file_manager.list_folders(
            user_id=user_id,
            include_subfolders=include_subfolders,
            skip=skip,
            limit=limit
        )

        # 캐시에 저장 (TTL: 5분)
        set_cache(cache_key, folders, settings.FOLDER_LIST_CACHE_TTL)

        return {
            "status": "success",
            "data": folders,
            "cache_hit": False
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{user_id}/folders/{folder_name}/files")
async def list_folder_files(
    user_id: int,
    folder_name: str,
    current_user: User = Depends(get_current_user),
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """
    특정 폴더의 파일 목록을 조회합니다.
    """
    if current_user.id != user_id:
        raise HTTPException(status_code=403, detail="자신의 파일만 조회할 수 있습니다")

    try:
        # Redis 캐시 키 생성
        cache_key = build_cache_key("files", user_id, folder_name)
        
        # 캐시된 데이터 확인
        cached_files = get_cache(cache_key)
        if cached_files is not None:
            return {
                "status": "success",
                "data": cached_files[:limit],
                "cache_hit": True
            }

        # DB에서 파일 목록 조회
        files = file_manager.list_files(
            user_id=user_id,
            folder_name=folder_name,
            limit=limit
        )

        # 캐시에 저장 (TTL: 5분)
        set_cache(cache_key, files, settings.FILE_LIST_CACHE_TTL)

        return {
            "status": "success",
            "data": files,
            "cache_hit": False
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/{user_id}/folders/{folder_name}/upload")
async def upload_file(
    user_id: int,
    folder_name: str,
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    파일을 업로드합니다.
    """
    if current_user.id != user_id:
        raise HTTPException(status_code=403, detail="자신의 폴더에만 업로드할 수 있습니다")

    try:
        file_path = await file_manager.save_pdf(user_id, folder_name, file)
        
        # 파일 업로드 후 캐시 갱신
        cache_key = build_cache_key("files", user_id, folder_name)
        cached_files = get_cache(cache_key)
        if cached_files:
            cached_files.append(file.filename)
            set_cache(cache_key, cached_files, settings.FILE_LIST_CACHE_TTL)

        return {
            "status": "success",
            "message": "파일 업로드 완료",
            "file_path": file_path
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/{user_id}/folders")
async def create_folder(
    user_id: int,
    folder_name: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    새 폴더를 생성합니다.
    """
    if current_user.id != user_id:
        raise HTTPException(status_code=403, detail="자신의 폴더만 생성할 수 있습니다")

    try:
        folder_path = file_manager.create_folder(user_id, folder_name)
        
        # 폴더 생성 후 캐시 갱신
        for include_subfolders in [True, False]:
            cache_key = build_cache_key("folders", user_id, include_subfolders)
            delete_cache(cache_key)

        return {
            "status": "success",
            "message": "폴더 생성 완료",
            "folder_path": str(folder_path)
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@router.post("/{user_id}/folders/{folder_name}/upload/chunk")
async def upload_chunk(
    user_id: int,
    folder_name: str,
    chunk_number: int = Form(...),
    total_chunks: int = Form(...),
    file_id: str = Form(None),  # None이면 새로운 ID 생성
    original_filename: str = Form(...),
    chunk: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """📌 대용량 파일의 청크를 업로드합니다."""
    if current_user.id != user_id:
        raise HTTPException(status_code=403, detail="자신의 폴더에만 업로드할 수 있습니다")
        
    try:
        # 파일 ID가 없으면 새로 생성
        if not file_id:
            file_id = str(uuid4())
            
        # 메타데이터 설정
        metadata = {
            "user_id": str(user_id),
            "folder_name": folder_name,
            "original_filename": original_filename,
            "total_chunks": total_chunks
        }
        
        # 청크 저장
        chunk_status = await chunk_manager.save_chunk(
            file_id=file_id,
            chunk_number=chunk_number,
            total_chunks=total_chunks,  # 추가
            chunk=chunk,
            metadata={
                "user_id": str(user_id),
                "folder_name": folder_name,
                "original_filename": original_filename
            }
        )
        
        return {
            "status": "success",
            "message": f"청크 {chunk_number + 1}/{total_chunks} 업로드 완료",
            "file_id": file_id,
            "chunk_status": chunk_status
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/{user_id}/folders/{folder_name}/upload/complete")
async def complete_chunked_upload(
    user_id: int,
    folder_name: str,
    request: CompleteUploadRequest,  # Pydantic 모델 사용
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """📌 청크 업로드 완료 후 파일을 병합합니다."""
    if current_user.id != user_id:
        raise HTTPException(status_code=403, detail="자신의 폴더에만 업로드할 수 있습니다")
        
    try:
        final_path = await chunk_manager.merge_chunks(request.file_id)
        
        return {
            "status": "success",
            "message": "파일 업로드 완료",
            "file_path": final_path
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))