import shutil
import aiofiles
import re
import time
from uuid import uuid4
from pathlib import Path
from fastapi import HTTPException, UploadFile
from typing import List, Optional, Dict
import os
import asyncio
from datetime import datetime
from pydantic import BaseModel
from itertools import islice
from app.core.redis_helper import get_cache, set_cache, build_cache_key, delete_cache


# ==================================================
# 1. 데이터 모델 및 예외 클래스
# ==================================================
class FolderResponse(BaseModel):
    """📌 폴더 정보 응답 모델"""
    name: str
    relative_path: str
    created_at: datetime
    subfolders: List[str]


class FileOperationError(Exception):
    """📌 파일 조작 관련 예외 클래스"""
    def __init__(self, message: str, code: int = 500):
        self.message = message
        self.code = code

class ApiResponse(BaseModel):
    """📌 표준 API 응답 모델"""
    operation: str
    status: str
    message: Optional[str] = None
    original_path: Optional[str] = None
    new_path: Optional[str] = None
    created: Optional[bool] = None


# ==================================================
# 2. 파일 저장 및 관리 클래스
# ==================================================
class FileStorageManager:
    """📂 파일 저장 및 관리 클래스"""

    def __init__(self):
        """📌 초기화: 기본 저장 경로 설정"""
        self.BASE_DIR = Path(os.getenv("STORAGE_PATH", "./storage")).resolve()
        self.BASE_DIR.mkdir(parents=True, exist_ok=True)

    # ==================================================
    # 2.1 유틸리티 메서드
    # ==================================================
    def _sanitize_path(self, user_id: int, *path_segments) -> Path:
        """📌 경로 보안 검증 및 생성"""
        try:
            user_id_str = str(user_id)
            full_path = self.BASE_DIR.joinpath(user_id_str, *path_segments).resolve()

            # 보안 검증: BASE_DIR 내에서만 허용
            if not str(full_path).startswith(str(self.BASE_DIR)):
                raise ValueError("잘못된 경로 접근 시도")

            return full_path
        except Exception as e:
            raise FileOperationError(str(e), 400)

    @staticmethod
    def _validate_name(name: str, is_file: bool = True) -> bool:
        """📌 파일/폴더명 유효성 검사"""
        pattern = r'^[a-zA-Z0-9ㄱ-ㅎ가-힣_\-().&@#%!$ ]+$'
        if is_file:
            pattern = r'^[a-zA-Z0-9ㄱ-ㅎ가-힣_\-().&@#%!$ ]+\.[a-zA-Z0-9]+$' 

        return bool(re.match(pattern, name))

    @staticmethod
    def _sanitize_name(name: str, is_file: bool = True) -> str:
        """📌 유효하지 않은 문자 자동 변환"""
        sanitized = re.sub(r'[^a-zA-Z0-9ㄱ-ㅎ가-힣_\-().&@#%!$ ]+', '', name)
        if is_file and '.' not in sanitized:
            sanitized += ".pdf"  # 확장자 자동 추가
        return sanitized.rstrip('.')  # 끝에 . 남지 않도록 정리

    def generate_unique_name(self, folder: Path, name: str) -> Path:
        """📌 동일한 이름이 존재하면 (1), (2) 숫자 추가"""
        new_path = folder / name
        count = 1
        while new_path.exists():
            file_stem, file_ext = os.path.splitext(name)
            new_path = folder / f"{file_stem}({count}){file_ext}"
            count += 1
        return new_path

    # ==================================================
    # 2.2 파일 업로드 관련 메서드
    # ==================================================
    async def save_pdf(self, user_id: int, folder_name: str, file: UploadFile) -> str:
        """📌 PDF 파일 저장"""
        try:
            if not file.filename.lower().endswith(".pdf"):
                raise FileOperationError("PDF 파일만 업로드 가능합니다.", 400)

            # ✅ 파일명 자동 정리
            filename = self._sanitize_name(file.filename)
            if not self._validate_name(filename):
                raise FileOperationError(f"잘못된 문자가 포함된 파일명: {filename}")

            # ✅ 경로 생성
            folder_path = self._sanitize_path(user_id, folder_name)
            folder_path.mkdir(parents=True, exist_ok=True)

            # ✅ 중복 파일명 방지
            file_path = self.generate_unique_name(folder_path, filename)

            async with aiofiles.open(file_path, "wb") as buffer:
                await buffer.write(await file.read())

            return str(file_path)

        except Exception as e:
            raise FileOperationError(f"파일 저장 실패: {str(e)}")

    async def save_multiple_pdfs(
        self,
        user_id: int,
        folder_name: str,
        files: List[UploadFile],
        overwrite: bool = False
    ) -> dict:
        """📌 여러 PDF 파일 일괄 저장 (병렬 처리)"""
        try:
            user_id_str = str(user_id)
            if not all(self._validate_name(n) for n in [user_id_str, folder_name]):
                raise FileOperationError("잘못된 문자가 포함된 이름")

            folder_path = self._sanitize_path(user_id, folder_name)
            folder_path.mkdir(parents=True, exist_ok=True)

            results = {
                "total": len(files),
                "success": [],
                "failed": []
            }

            # 병렬 처리 코루틴 생성
            tasks = [self._process_single_file(f, folder_path, overwrite) for f in files]
            file_results = await asyncio.gather(*tasks, return_exceptions=True)

            for result in file_results:
                if isinstance(result, Exception):
                    results["failed"].append(str(result))
                else:
                    results["success"].append(result)

            return results

        except FileOperationError as e:
            raise e
        except Exception as e:
            raise FileOperationError(f"일괄 업로드 실패: {str(e)}")

    async def _process_single_file(
        self,
        file: UploadFile,
        folder_path: Path,
        overwrite: bool
    ) -> dict:
        """📌 개별 파일 처리 코루틴"""
        try:
            # 확장자 검증
            if not file.filename.lower().endswith(".pdf"):
                raise ValueError(f"'{file.filename}': PDF 파일만 허용됩니다")

            # 파일명 생성
            filename = f"{uuid4().hex}_{file.filename}"
            if not self._validate_name(filename):
                raise ValueError(f"'{file.filename}': 유효하지 않은 파일명")

            file_path = folder_path / filename

            # 덮어쓰기 방지
            if file_path.exists() and not overwrite:
                raise ValueError(f"'{file.filename}': 동일한 파일명 존재")

            # 비동기 저장
            async with aiofiles.open(file_path, "wb") as buffer:
                await buffer.write(await file.read())

            return {
                "original_name": file.filename,
                "saved_name": filename,
                "size": file_path.stat().st_size,
                "path": str(file_path)
            }

        except Exception as e:
            raise e

    # ==================================================
    # 2.3 파일 관리 메서드
    # ==================================================
    # app/services/file_service.py

    def list_files(self, user_id: int, folder_name: str, limit: int = 100) -> List[str]:
        """파일 목록 조회 (최대 100개 제한)"""
        try:
            # Redis 캐시 키 생성
            cache_key = build_cache_key("files", user_id, folder_name)
            
            # 캐시된 데이터 확인
            cached_files = get_cache(cache_key)
            if cached_files is not None:
                return cached_files[:limit]
                
            folder_path = self._sanitize_path(user_id, folder_name)
            
            if not folder_path.exists():
                raise FileOperationError(f"폴더 '{folder_name}'을 찾을 수 없습니다.", 404)

            if not folder_path.is_dir():
                raise FileOperationError(f"'{folder_name}'은 폴더가 아닙니다.", 400)

            files = [f.name for f in folder_path.iterdir() if f.is_file()][:limit]
            
            # 캐시에 저장
            set_cache(cache_key, files)
            
            return files

        except FileOperationError as e:
            raise e
        except Exception as e:
            raise FileOperationError(f"파일 목록 조회 실패: {str(e)}", 500)   


    def delete_file(self, user_id: int, folder_name: str, filename: str) -> None:
        """파일 삭제"""
        try:
            file_path = self._sanitize_path(user_id, folder_name, filename)
            if file_path.exists():
                file_path.unlink()
                # 파일 목록 캐시 삭제
                cache_key = build_cache_key("files", user_id, folder_name)
                delete_cache(cache_key)
            else:
                raise FileOperationError("파일을 찾을 수 없습니다.", 404)
        except FileOperationError as e:
            raise e
        except Exception as e:
            raise FileOperationError(str(e), 500)

    def rename_file(self, user_id: int, folder_name: str, file_name: str, new_name: str) -> Path:
        """파일 이름 변경"""
        try:
            if not self._validate_name(file_name) or not self._validate_name(new_name):
                raise FileOperationError("유효하지 않은 파일명")

            old_path = self._sanitize_path(user_id, folder_name, file_name)
            if not old_path.exists():
                raise FileOperationError("파일을 찾을 수 없습니다.")

            file_ext = old_path.suffix
            new_name_with_ext = f"{new_name}{file_ext}"
            new_path = self.generate_unique_filename(old_path.parent, new_name_with_ext)
            old_path.rename(new_path)

            # 파일 목록 캐시 갱신
            cache_key = build_cache_key("files", user_id, folder_name)
            delete_cache(cache_key)

            return new_path

        except FileOperationError as e:
            raise e
        except Exception as e:
            raise FileOperationError(f"파일 이름 변경 실패: {str(e)}")

    # ==================================================
    # 2.4 폴더 관리 메서드
    # ==================================================
    def create_folder(self, user_id: int, folder_name: str) -> Path:
        """폴더 생성 (멱등성 유지)"""
        try:
            folder_path = self._sanitize_path(user_id, folder_name)
            folder_path.mkdir(parents=True, exist_ok=True)
            
            # 폴더 목록 캐시 갱신
            cache_key = build_cache_key("folders", user_id, True)  # include_subfolders=True
            delete_cache(cache_key)
            cache_key = build_cache_key("folders", user_id, False)  # include_subfolders=False
            delete_cache(cache_key)
            
            return folder_path
        except Exception as e:
            raise FileOperationError(f"폴더 생성 실패: {str(e)}", 400)

    def delete_folder(self, user_id: int, folder_name: str) -> None:
        """폴더 삭제 (재귀적 삭제)"""
        try:
            folder_path = self._sanitize_path(user_id, folder_name)
            if folder_path.exists():
                shutil.rmtree(folder_path)
                
                # 폴더 목록 캐시 삭제
                cache_key = build_cache_key("folders", user_id, True)
                delete_cache(cache_key)
                cache_key = build_cache_key("folders", user_id, False)
                delete_cache(cache_key)
                
                # 해당 폴더의 파일 목록 캐시도 삭제
                files_cache_key = build_cache_key("files", user_id, folder_name)
                delete_cache(files_cache_key)
                
        except FileNotFoundError:
            pass
        except Exception as e:
            raise FileOperationError(str(e), 500)   

    def list_folders(
        self, user_id: int, include_subfolders: bool = False, skip: int = 0, limit: int = 100
    ) -> List[dict]:  # 반환 타입을 dict로 변경
        """사용자 폴더 목록 조회"""
        try:
            # Redis 캐시 키 생성
            cache_key = build_cache_key("folders", user_id, include_subfolders)
            
            # 캐시된 데이터 확인
            cached_folders = get_cache(cache_key)
            if cached_folders is not None:
                return cached_folders[skip:skip + limit]
                
            user_path = self._sanitize_path(user_id)

            if not user_path.exists():
                return []

            folders = []
            for folder in user_path.iterdir():
                if folder.is_dir() and self._validate_name(folder.name, is_file=False):
                    created_time = datetime.fromtimestamp(folder.stat().st_ctime)
                    
                    folder_info = {
                        "name": folder.name,
                        "relative_path": f"/{user_id}/{folder.name}",
                        "created_at": created_time.isoformat(),
                        "subfolders": []
                    }

                    if include_subfolders:
                        subfolders = [
                            sub.name for sub in folder.iterdir()
                            if sub.is_dir() and self._validate_name(sub.name, is_file=False)
                        ][:100]
                        folder_info["subfolders"] = subfolders

                    folders.append(folder_info)

            sorted_folders = sorted(folders, key=lambda x: x["created_at"], reverse=True)
            
            # 캐시에 저장
            set_cache(cache_key, sorted_folders)
            
            return sorted_folders[skip:skip + limit]

        except Exception as e:
            raise FileOperationError(f"폴더 목록 조회 실패: {str(e)}", 500)
        
    def generate_unique_foldername(self, folder: Path) -> Path:   
        """📌 중복 폴더 처리: `(1)`, `(2)` 추가"""
        new_path = folder
        count = 1
        while new_path.exists():
            new_path = folder.parent / f"{folder.name}({count})"
            count += 1
        return new_path    

    def move_folder(
        self, user_id: int, old_folder: str, new_folder: str, create_if_not_exists: bool = False
    ) -> Path:
        """폴더 이동 기능"""
        try:
            old_folder = self._sanitize_name(old_folder, is_file=False)
            new_folder = self._sanitize_name(new_folder, is_file=False)

            if not self._validate_name(old_folder, is_file=False) or \
            not self._validate_name(new_folder, is_file=False):
                raise FileOperationError("유효하지 않은 폴더명")

            old_path = self._sanitize_path(user_id, old_folder)
            if not old_path.exists():
                raise FileOperationError("폴더를 찾을 수 없습니다.")

            new_folder_path = self._sanitize_path(user_id, new_folder)
            if not new_folder_path.exists():
                if create_if_not_exists:
                    new_folder_path.mkdir(parents=True, exist_ok=True)
                else:
                    raise FileOperationError("대상 폴더가 존재하지 않습니다.")

            new_path = self.generate_unique_name(new_folder_path, old_path.name)
            shutil.move(str(old_path), str(new_path))

            # 캐시 갱신
            for include_subfolders in [True, False]:
                cache_key = build_cache_key("folders", user_id, include_subfolders)
                delete_cache(cache_key)

            # 이동된 폴더의 파일 목록 캐시도 삭제
            files_cache_key = build_cache_key("files", user_id, old_folder)
            delete_cache(files_cache_key)
            files_cache_key = build_cache_key("files", user_id, new_folder)
            delete_cache(files_cache_key)

            return Path(f"/{user_id}/{new_path.name}")

        except FileOperationError as e:
            raise HTTPException(status_code=400, detail=str(e))
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"폴더 이동 실패: {str(e)}") 
        
class ChunkManager:
    """📌 청크 업로드 관리 클래스"""
    
    def __init__(self):
        """📌 초기화: 임시 저장소 설정"""
        self.CHUNK_DIR = Path(os.getenv("CHUNK_STORAGE_PATH", "./storage/chunks")).resolve()
        self.CHUNK_DIR.mkdir(parents=True, exist_ok=True)
        
    def _get_chunk_path(self, file_id: str, chunk_number: int) -> Path:
        """📌 청크 파일 경로 생성"""
        return self.CHUNK_DIR / f"{file_id}_{chunk_number}"
        
    async def save_chunk(
        self,
        file_id: str,
        chunk_number: int,
        total_chunks: int,  
        chunk: UploadFile,
        metadata: dict
    ) -> dict:
        """📌 청크 저장 및 상태 관리"""
        try:
            # 청크 저장
            chunk_path = self._get_chunk_path(file_id, chunk_number)
            async with aiofiles.open(chunk_path, "wb") as buffer:
                content = await chunk.read()
                await buffer.write(content)
                
            # Redis에 업로드 상태 저장
            upload_key = build_cache_key("upload", file_id)
            
            # 현재 상태 조회
            current_status = get_cache(upload_key) or {}
            
            # 상태 업데이트
            current_status.update({
                f"chunk_{chunk_number}": "completed",
                "total_chunks": total_chunks,
                **metadata
            })
            
            # 업데이트된 상태 저장
            set_cache(upload_key, current_status)
            
            return {
                "chunk_number": chunk_number,
                "total_chunks": total_chunks,
                "is_complete": self._is_upload_complete(file_id)
            }
            
        except Exception as e:
            raise FileOperationError(f"청크 저장 실패: {str(e)}")
            
    def _is_upload_complete(self, file_id: str) -> bool:
        """📌 모든 청크가 업로드되었는지 확인"""
        upload_key = build_cache_key("upload", file_id)
        upload_info = get_cache(upload_key)
        
        if not upload_info:
            return False
            
        total_chunks = int(upload_info.get("total_chunks", 0))
        completed_chunks = len([k for k in upload_info.keys() if k.startswith("chunk_")])
        
        return completed_chunks == total_chunks
        
    async def merge_chunks(self, file_id: str) -> str:
        """📌 청크 병합 및 최종 파일 생성"""
        try:
            # 업로드 정보 조회
            upload_key = build_cache_key("upload", file_id)
            upload_info = get_cache(upload_key)
            
            if not upload_info:
                raise FileOperationError("업로드 정보를 찾을 수 없습니다")
                
            total_chunks = int(upload_info["total_chunks"])
            user_id = int(upload_info["user_id"])  # int로 변환
            folder_name = upload_info["folder_name"]
            original_filename = upload_info["original_filename"]
            
            # FileStorageManager를 통해 최종 저장 경로 설정
            file_manager = FileStorageManager()
            final_path = file_manager._sanitize_path(
                user_id,
                folder_name,
                original_filename
            )
            
            # 청크 병합
            async with aiofiles.open(final_path, "wb") as outfile:
                for i in range(total_chunks):
                    chunk_path = self._get_chunk_path(file_id, i)
                    if not chunk_path.exists():
                        raise FileOperationError(f"청크 파일이 없습니다: {i}")
                        
                    async with aiofiles.open(chunk_path, "rb") as infile:
                        await outfile.write(await infile.read())
                        
                    # 청크 파일 삭제
                    chunk_path.unlink()
                    
            # Redis 업로드 정보 삭제
            delete_cache(upload_key)
            
            # 파일 목록 캐시 갱신
            cache_key = build_cache_key("files", user_id, folder_name)
            delete_cache(cache_key)
            
            return str(final_path)
            
        except Exception as e:
            raise FileOperationError(f"청크 병합 실패: {str(e)}")