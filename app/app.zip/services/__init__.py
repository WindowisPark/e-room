# app/services/__init__.py

from .file_service import FileStorageManager

__all__ = ["FileStorageManager"]
