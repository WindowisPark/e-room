# app/models/__init__.py
# 순환 참조 방지를 위해 여기서 직접 임포트하지 않음