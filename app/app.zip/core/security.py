from datetime import datetime, timedelta
from typing import Any, Union, Optional
from jose import jwt, JWTError
from passlib.context import CryptContext
from redis import Redis
from redis.exceptions import RedisError
from fastapi.security import OAuth2PasswordBearer
from fastapi import Depends, HTTPException, status
from sqlalchemy.orm import Session
import os
import logging

from app.core.config import settings
from app.db.session import get_db
from app.schemas.token import TokenPayload

# 비밀번호 해싱
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# OAuth2 설정
oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{settings.API_V1_STR}/auth/login")

# 로깅 설정
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# 토큰 시크릿 키
ACCESS_SECRET_KEY = settings.ACCESS_SECRET_KEY
REFRESH_SECRET_KEY = settings.REFRESH_SECRET_KEY

# Redis 설정
REDIS_HOST = os.getenv("REDIS_HOST", "redis")
try:
   redis_client = Redis(host=REDIS_HOST, port=6379, db=0)
   redis_client.ping()
   logger.info("Redis connection successful")
except Exception as e:
   logger.error(f"Redis connection failed: {str(e)}")
   redis_client = None

def verify_password(plain_password: str, hashed_password: str) -> bool:
   """
   Plain text 비밀번호와 해시된 비밀번호를 비교하여 검증
   """
   return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str) -> str:
   """
   비밀번호를 해시화
   """
   return pwd_context.hash(password)

def create_access_token(subject: str, expires_delta: Optional[timedelta] = None) -> str:
   """
   Access Token 생성
   """
   if expires_delta:
       expire = datetime.utcnow() + expires_delta
   else:
       expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
   
   to_encode = {"exp": expire, "sub": str(subject)}
   return jwt.encode(to_encode, ACCESS_SECRET_KEY, algorithm="HS256")

def create_refresh_token(subject: Union[str, Any], expires_delta: Optional[timedelta] = None) -> str:
   """
   Refresh Token 생성
   """
   expire = datetime.utcnow() + (expires_delta or timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS))
   to_encode = {"exp": expire, "sub": str(subject)}
   return jwt.encode(to_encode, REFRESH_SECRET_KEY, algorithm="HS256")

def verify_refresh_token(token: str) -> Optional[int]:
   """
   Refresh Token 검증 및 Redis에서 확인
   """
   try:
       payload = jwt.decode(token, REFRESH_SECRET_KEY, algorithms=["HS256"])
       user_id = int(payload.get("sub"))
       
       if redis_client:
           stored_token = redis_client.get(f"refresh:{user_id}")
           if not stored_token or stored_token.decode() != token:
               logger.warning(f"Refresh token mismatch or not found for user {user_id}")
               return None
       return user_id
   except JWTError as e:
       logger.error(f"Failed to verify refresh token: {str(e)}")
       return None

def store_refresh_token(user_id: int, refresh_token: str, expires_in: int):
   """
   Redis에 Refresh Token 저장
   """
   if redis_client:
       try:
           redis_client.setex(f"refresh:{user_id}", expires_in, refresh_token)
       except RedisError as e:
           logger.error(f"Failed to store refresh token: {str(e)}")
   else:
       logger.warning(f"Redis is disabled. Refresh token not stored for user {user_id}")

def delete_refresh_token(user_id: int):
   """
   Redis에서 Refresh Token 삭제
   """
   if redis_client:
       try:
           redis_client.delete(f"refresh:{user_id}")
       except RedisError as e:
           logger.error(f"Failed to delete refresh token: {str(e)}")

def verify_access_token(token: str) -> Optional[int]:
   """
   Access Token 검증
   """
   try:
       payload = jwt.decode(token, ACCESS_SECRET_KEY, algorithms=["HS256"])
       user_id = int(payload.get("sub"))
       expire = datetime.fromtimestamp(payload.get("exp"))
       
       if expire < datetime.utcnow():
           logger.warning(f"Access token expired for user {user_id}")
           return None
           
       return user_id
   except JWTError as e:
       logger.error(f"Failed to verify access token: {str(e)}")
       return None

async def get_current_user(
   db: Session = Depends(get_db),
   token: str = Depends(oauth2_scheme)
):
   """
   현재 인증된 사용자 정보 조회
   """
   credentials_exception = HTTPException(
       status_code=status.HTTP_401_UNAUTHORIZED,
       detail="Could not validate credentials",
       headers={"WWW-Authenticate": "Bearer"},
   )
   
   try:
       user_id = verify_access_token(token)
       if user_id is None:
           raise credentials_exception
           
   except JWTError:
       raise credentials_exception

   # 순환 참조 방지를 위해 여기서 import
   from app.crud.crud_user import user    
   current_user = user.get(db, id=user_id)
   
   if not current_user:
       raise credentials_exception
       
   return current_user

async def validate_token_pair(
   access_token: str,
   refresh_token: str
) -> tuple[bool, bool]:
   """
   Access Token과 Refresh Token 쌍의 유효성 검증
   
   Returns:
       tuple[bool, bool]: (access_token_valid, refresh_token_valid)
   """
   access_token_valid = verify_access_token(access_token) is not None
   refresh_token_valid = verify_refresh_token(refresh_token) is not None
   
   return access_token_valid, refresh_token_valid

def revoke_all_tokens(user_id: int):
   """
   사용자의 모든 토큰 폐기 (로그아웃 등에 사용)
   """
   delete_refresh_token(user_id)
   # Access Token은 저장하지 않으므로 자동 만료되기를 기다림
   logger.info(f"All tokens revoked for user {user_id}")

def get_token_expiry() -> tuple[int, int]:
   """
   Access Token과 Refresh Token의 만료 시간 반환
   
   Returns:
       tuple[int, int]: (access_token_expires_in, refresh_token_expires_in) in seconds
   """
   access_expires = settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
   refresh_expires = settings.REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60
   
   return access_expires, refresh_expires