#app/core/redis_helper.py

import os
import json
import logging
from typing import Optional, Any
from redis import Redis, RedisError

# 로깅 설정
logger = logging.getLogger(__name__)

# 환경 변수에서 Redis 설정 로드
REDIS_HOST = os.getenv("REDIS_HOST", "redis")
REDIS_PORT = int(os.getenv("REDIS_PORT", 6379))
REDIS_DB = int(os.getenv("REDIS_DB", 0))

# 기본 TTL 설정 (24시간)
DEFAULT_TTL = 24 * 60 * 60

# Redis 클라이언트 초기화
try:
    redis_client = Redis(host=REDIS_HOST, port=REDIS_PORT, db=REDIS_DB, decode_responses=True)
    redis_client.ping()  # Redis 연결 확인
except RedisError as e:
    logger.error(f"Redis 연결 실패: {str(e)}")
    redis_client = None  # 폴백 처리

def get_cache(key: str) -> Optional[Any]:
    """
    Redis에서 캐시된 데이터를 조회.
    
    Args:
        key: 캐시 키
    
    Returns:
        캐시된 데이터 (없으면 None)
    """
    try:
        if redis_client is None:
            return None
            
        data = redis_client.get(key)
        if data:
            return json.loads(data)
        return None
    except RedisError as e:
        logger.error(f"캐시 조회 실패: {str(e)}")
        return None

def set_cache(key: str, value: Any, ttl: int = DEFAULT_TTL) -> bool:
    """
    Redis에 데이터를 캐시.
    
    Args:
        key: 캐시 키
        value: 캐시할 데이터
        ttl: 캐시 유효 기간 (초)
    
    Returns:
        성공 여부
    """
    try:
        if redis_client is None:
            return False
            
        redis_client.setex(
            name=key,
            time=ttl,
            value=json.dumps(value)
        )
        return True
    except RedisError as e:
        logger.error(f"캐시 저장 실패: {str(e)}")
        return False

def delete_cache(key: str) -> bool:
    """
    Redis에서 캐시를 삭제합니다.
    
    Args:
        key: 캐시 키
    
    Returns:
        성공 여부
    """
    try:
        if redis_client is None:
            return False
            
        redis_client.delete(key)
        return True
    except RedisError as e:
        logger.error(f"캐시 삭제 실패: {str(e)}")
        return False

def build_cache_key(prefix: str, *args) -> str:
    """
    캐시 키를 생성합니다.
    
    Args:
        prefix: 캐시 키 접두사
        args: 캐시 키에 포함될 추가 인자들
    
    Returns:
        생성된 캐시 키
    """
    return f"{prefix}:{':'.join(str(arg) for arg in args)}"
